// 마지막 방문 시간 설정: 닉네임 보여주기 연출 여부 판별
export function SET_LASTVISITED(state, lastVisited) {
  state.lastVisited = lastVisited
}

// 닉네임 설정
export function SET_NICKNAME(state, nickname) {
  state.nickname = nickname
}