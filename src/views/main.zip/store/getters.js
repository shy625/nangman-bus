// 마지막 방문 시간: 닉네임 보여주기 연출 여부 판별
export function lastVisitedDate(state) {
  return state.lastVisited
}

// 저장된 닉네임 보여주기
// 그런데, 필요한지 아직 모르겠음
export function offerNickname(state) {
  return state.nickname
}