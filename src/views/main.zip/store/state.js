export default {
  state: {
    lastVisited: '2022-08-05T22:03:00',
    nickname: '',
    
  }
}