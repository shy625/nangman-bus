<template>
  <div>
    지금
    <!-- '양재IC' -->
    <!-- 앞 정류장명 마지막 글자가 받침이 있는지 없는지 -->을 지나는
    <!-- '5100' -->번
    버스는
    <!-- '아주 시끌벅적하네요!' -->
  </div>
</template>
<script setup>
  import { useStore } from 'vuex'
  import { ref, onMounted } from 'vue'
  const store = useStore()
  onMounted(() => {
  })
  const dataNameExample = ref({
    
  })
  const fName = function (event) {
    
  }
</script>