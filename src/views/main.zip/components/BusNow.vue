<template>
  도로위 낭만버스 ㅡㅡㅡ
  <!-- BusBowItem에 내용 채워서 3개 가져옴 -->
</template>
<script setup>
  import { useStore } from 'vuex'
  import { ref, onMounted } from 'vue'
  const store = useStore()
  onMounted(() => {
  })
  const dataNameExample = ref({
    
  })
  const fName = function (event) {
    
  }
</script>