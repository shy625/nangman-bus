package com.nangman.db.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 채팅방 입퇴장 기록 모델 정의.
 */
@Entity(name = "chat_in_out_record")
@Getter
@Setter
public class ChatInOutRecord extends BaseEntity {

    private LocalDateTime InTime;

    private LocalDateTime outTime;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public void setUser(User user) {
        this.user = user;
        if (!user.getChatInOutRecords().contains(this)) {
            user.getChatInOutRecords().add(this);
        }
    }

    @ManyToOne
    @JoinColumn(name = "chatting_room_id")
    private ChattingRoom chattingRoom;

    public void setChattingRoom(ChattingRoom chattingRoom) {
        this.chattingRoom = chattingRoom;

        if (!chattingRoom.getChatInOutRecords().contains(this)) {
            chattingRoom.getChatInOutRecords().add(this);
        }
    }
}
