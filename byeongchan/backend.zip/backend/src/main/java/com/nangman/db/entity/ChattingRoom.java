package com.nangman.db.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 닉네임 모델 정의.
 */
@Entity(name = "chatting_room")
@Getter
@Setter
public class ChattingRoom extends BaseEntity {

    private LocalDateTime terminatedDate;

    @ManyToOne
    @JoinColumn(name = "bus_id")
    private Bus bus;

    public void setBus(Bus bus) {
        this.bus = bus;

        if (!bus.getChattingRooms().contains(this)) {
            bus.getChattingRooms().add(this);
        }
    }

    @OneToMany(mappedBy = "chattingRoom")
    private List<Chatting> chattings = new ArrayList<>();

    public void addChatting(Chatting chatting) {
        this.chattings.add(chatting);

        if (chatting.getChattingRoom() != this) {
            chatting.setChattingRoom(this);
        }
    }


    @OneToOne
    @JoinColumn(name = "report_id")
    private Report report;

    @OneToMany(mappedBy = "chattingRoom")
    private List<ChatInOutRecord> chatInOutRecords = new ArrayList<>();

    public void addChatInOutRecord(ChatInOutRecord chatInOutRecord) {
        this.chatInOutRecords.add(chatInOutRecord);

        if (chatInOutRecord.getChattingRoom() != this) {
            chatInOutRecord.setChattingRoom(this);
        }
    }
}
